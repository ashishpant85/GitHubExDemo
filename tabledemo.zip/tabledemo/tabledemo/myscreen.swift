


import UIKit

class List: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    
 
    @IBOutlet weak var tblInnerView: UITableView!
    
    let textLabel = ["Jordan Smith", "Jordan Smith", "Jordan Smith", "Jordan Smith" ,"Jordan Smith" , "Jordan Smith" , "Jordan Smith"]
    
    let textLabel1 = ["John Smith", "John Smith", "John Smith", "John Smith" ,"John Smith" , "John Smith" , "John Smith"]
    
    let subLabel = ["Sales Assoc. at Google", "Sales Assoc. at Google", "Sales Assoc. at Google", "Sales Assoc. at Google" ,"Sales Assoc. at Google" , "Sales Assoc. at Google" , "Sales Assoc. at Google"]
    
    let ratingLabel = ["1", "2", "3", "4" ,"5" , "6" , "7"]
    
    let cellReuseIdentifier = "Cell"
    
    
    @IBAction func btnBackClicked(_ sender: Any)
    {
        _ = self.navigationController?.popViewController(animated: true)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        tblInnerView.dataSource = self
        tblInnerView.delegate = self
       
        

      
    
    
    }
    
    //Mark:TableView Delegate
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        var count:Int?
        
        if tableView == self.tblInnerView
        {
            count = textLabel.count
        }
        
//        if tableView == self.tblGoogleReview
//        {
//            count =  textLabel.count
//        }
        
        return count!
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell1 = tableView.dequeueReusableCell(withIdentifier:cellReuseIdentifier) as! InnerCircleReviewCell
            
            cell1.titleText.text = textLabel[indexPath.row]
            cell1.subTitleText.text = subLabel[indexPath.row]
            cell1.tableImage?.image = UIImage(named:"profile")
            cell1.ratingValue.text = ratingLabel[indexPath.row]
            
        return cell1
        
        }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 230
        
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        print("You tapped cell number \(indexPath.row).")
        if tableView == self.tblInnerView
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier:"InnerCircleDetailReview") as!
                InnerCircleDetailReview
          
            self.navigationController?.pushViewController(vc, animated: true)
        }
            
        else
            
        {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = storyboard.instantiateViewController(withIdentifier:"InnerCircleDetailReview") as! InnerCircleDetailReview
            
            self.navigationController?.pushViewController(vc, animated: true)
            
        }

        
        
        
        
    }
    


    

    
}
